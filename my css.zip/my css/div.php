<!doctype html>
<html>
	
<?php include ('html/head.html');?>


<body>
<?php include ('html/div1.html');?>

<?php include ('html/footer.html');?>

</body>
</html>