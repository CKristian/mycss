<!doctype html>
<html>
<head>
<meta charset="UTF-8">
<title>Untitled Document</title>
	
	<style> 
		a:link{color:red;}
		a:visited{color:purple;}
		input[type=radio]:checked+label{color:blue;}
		a:hover{
			border-bottom: 3px solid black;
		}
		p:not(#text){color: blue;}
	
		p::first-line{
			font-weight: bold;
			font-size: 1.2em;
			color: red;
		}
		li:nth-child(4n){
			color:green;
			font-size: 25px;
		}
		h2:nth-of-type(3n){
			border: 1px solid black;
		}
	
	</style>
	
	
</head>

<body>
	
<h1>Puteti accesa acest link <a href="https://www.w3schools.com">Acesta este un link.</a></h1>	
	<p>Lorem ipsum dolor sit amet, consectetur adipisicing elit. Vel doloremque, voluptate deserunt explicabo cum provident harum quidem atque impedit corrupti cupiditate corporis earum dolores omnis, dolorem in sed itaque ea.</p>
	<form>
		<input type="radio" name="rad" value="radio Buton">
		<label for="rad">Radio Buton</label>
		<input type="radio" name="rad" value="radio Buton">
		<label for="rad">Radio Buton2</label>
	</form>
	
	<p id="text">Lorem ipsum dolor sit amet, consectetur adipisicing elit. Porro assumenda <a href="#">tempore neque</a> repudiandae iure aliquid, odio architecto iste est. Quibusdam, quo. Quasi beatae eum praesentium, iusto perspiciatis voluptates harumh64ug7jhdwpu dwufhud hfeupedfueq u dwufg xqfxqpefgpr gf7pger</p>
	<p>Lorem ipsum dolor sit amet, consectetur adipisicing elit. Porro assumenda tempore neque repudiandae iure aliquid, odio architecto iste est. Quibusdam, quo. Quasi beatae eum praesentium, iusto perspiciatis voluptates harum  sudhfuwed fxewuigf ueqwg qpxfprefxeyw xgfre gxgqfergxferwug xf78r gf</p>
	<p>Lorem ipsum dolor sit amet, consectetur adipisicing elit. Porro assumenda tempore neque <a href="#">repudiandae </a>iure aliquid, odio architecto iste est. Quibusdam, quo. Quasi beatae eum praesentium, iusto perspiciatis voluptates harum dxsbdfuigwef wergf x reyg fywer xfyger fxgweyfg fxygewgfxyegwr yxgferwfgr</p>
	<p>Lorem ipsum dolor sit amet, consectetur adipisicing elit. Porro assumenda tempore neque repudiandae iure aliquid, odio architecto iste est. Quibusdam, quo. Quasi beatae eum praesentium, iusto perspiciatis voluptates harum bdfgpuew pfxrgxfygrweuf gweufuehw pf rew</p>
	<ol>
		<li>item</li>
		<li>item</li>
		<li>item</li>
		<li>item</li>
		<li>item</li>
		<li>item</li>
		<li>item</li>
		<li>item</li>
		<li>item</li>
		<li>item</li>
	</ol>
	
	<h2>Lorem ipsum dolor sit amet, consectetur adipisicing elit. Ab quis rerum nobis quas, delectus asperiores voluptate magni velit cum dolores praesentium, cumque vitae. Suscipit perspiciatis in facere repudiandae, eveniet nemo.</h2>
	<h2>Lorem ipsum dolor sit amet, consectetur adipisicing elit. Ab quis rerum nobis quas, delectus asperiores voluptate magni velit cum dolores praesentium, cumque vitae. Suscipit perspiciatis in facere repudiandae, eveniet nemo.</h2>
	<h2>Lorem ipsum dolor sit amet, consectetur adipisicing elit. Ab quis rerum nobis quas, delectus asperiores voluptate magni velit cum dolores praesentium, cumque vitae. Suscipit perspiciatis in facere repudiandae, eveniet nemo.</h2>
	<h2>Lorem ipsum dolor sit amet, consectetur adipisicing elit. Ab quis rerum nobis quas, delectus asperiores voluptate magni velit cum dolores praesentium, cumque vitae. Suscipit perspiciatis in facere repudiandae, eveniet nemo.</h2>
	<h2>Lorem ipsum dolor sit amet, consectetur adipisicing elit. Ab quis rerum nobis quas, delectus asperiores voluptate magni velit cum dolores praesentium, cumque vitae. Suscipit perspiciatis in facere repudiandae, eveniet nemo.</h2>
	<h2>Lorem ipsum dolor sit amet, consectetur adipisicing elit. Ab quis rerum nobis quas, delectus asperiores voluptate magni velit cum dolores praesentium, cumque vitae. Suscipit perspiciatis in facere repudiandae, eveniet nemo.</h2>
	
</body>
</html>