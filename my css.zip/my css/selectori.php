<!doctype html>
<html>
<head>
<meta charset="UTF-8">
<title>Selectori</title>
<style type="text/css">	
	* {
		margin=0;
		padding=0;
		border=none;
		font-size: 12px;
		font-family: Verdana, Arial, sans-serif;
	}
	h1 {
		font-size: 22px;
		font-weight: bold;
	}
	p, section, article, h3 {
		color: green;
	}
	#yellow{
		color: red;
		text-align: center;

	}
	.paragraf{
		color:blueviolet;
		font-size:15px;
		font-style: italic;
	}
	
</style>	
</head>

<body>
	<h1>Selectroi de tip element, ID, class.</h1>
	<p id='yellow'>Lorem ipsum dolor sit amet, consectetur adipisicing elit. Nobis, tempore iste delectus, officia dolorem natus sequi nesciunt necessitatibus reprehenderit, voluptatibus sint reiciendis ullam. Modi voluptatem eaque nemo nobis dicta rem.</p>
	<p class="paragraf">Lorem ipsum dolor sit amet, consectetur adipisicing elit. Nobis, tempore iste delectus, officia dolorem natus sequi nesciunt necessitatibus reprehenderit, voluptatibus sint reiciendis ullam. Modi voluptatem eaque nemo nobis dicta rem.</p>
	<p class="paragraf">Lorem ipsum dolor sit amet, consectetur adipisicing elit. Nobis, tempore iste delectus, officia dolorem natus sequi nesciunt necessitatibus reprehenderit, voluptatibus sint reiciendis ullam. Modi voluptatem eaque nemo nobis dicta rem.</p>
	<p class="paragraf">Lorem ipsum dolor sit amet, consectetur adipisicing elit. Nobis, tempore iste delectus, officia dolorem natus sequi nesciunt necessitatibus reprehenderit, voluptatibus sint reiciendis ullam. Modi voluptatem eaque nemo nobis dicta rem.</p>
	<p>Lorem ipsum dolor sit amet, consectetur adipisicing elit. Excepturi eos esse tempora eum deserunt! Corporis inventore a dolorem sed fuga nam delectus temporibus quos nemo numquam, explicabo doloremque voluptatum, quisquam.</p>
	
</body>
</html>