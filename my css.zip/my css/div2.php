<!doctype html>
<html>
<link href="/my css/css/style.css" rel="stylesheet" type="text/css">
<?php include ('html/head.html');?>

<body>
<div class="box2 bg">Content for  class "box2" Goes Here HEADER</div>
<div class="box2 bg">Content for  class "box2" Goes Here NAV</div>
<div class="box2 inal">	
<div class="sidebar bg">Content for  class "box2" Goes Here SIDEBAR
  	<main class="main"> Content for  class "main" Goes Here
    	<article class="art bg">Content for  class "article" Goes Here</article>
    	<section class="sec bg">Content for  class "section" Goes Here</section>
	</main>
	<br class="clear">
</div>
</div>
<div class="box2 bg">Content for  class "box2" Goes Here FOOTER</div>
	
	
</body>
</html>