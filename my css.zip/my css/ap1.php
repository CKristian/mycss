<!doctype html>
<html>
<head>
<meta charset="UTF-8">
<title>Untitled Document</title>
	<style>
	
		div{
			padding: 20px;
			border: thin solid red;
			color: green;
			background-color: blueviolet;
		}
		div+p{
			color: antiquewhite;
		}
		div>div{
			background-color:lightgoldenrodyellow;
			color: black;
		}
		div>div>div{
			background-color: chartreuse;
			color: darkslategrey;
		}
	
	
	</style>
	
</head>

<body>
	
<div>
	 <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit. Non reiciendis qui veniam, sed. Quaerat, fugiat, ad alias nisi, debitis et sint eveniet pariatur reprehenderit dolor dolorum velit similique enim sapiente?</p>
	 <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit. Non reiciendis qui veniam, sed. Quaerat, fugiat, ad alias nisi, debitis et sint eveniet pariatur reprehenderit dolor dolorum velit similique enim sapiente?</p>
     <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit. Non reiciendis qui veniam, sed. Quaerat, fugiat, ad alias nisi, debitis et sint eveniet pariatur reprehenderit dolor dolorum velit similique enim sapiente?</p>
  		<div>
		  <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit. Sit at, totam atque reprehenderit et veniam saepe incidunt enim cupiditate, vero sapiente nostrum recusandae optio, sequi ullam, reiciendis quisquam nobis quia.</p>
		  <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit. Sit at, totam atque reprehenderit et veniam saepe incidunt enim cupiditate, vero sapiente nostrum recusandae optio, sequi ullam, reiciendis quisquam nobis quia.</p>
		  <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit. Sit at, totam atque reprehenderit et veniam saepe incidunt enim cupiditate, vero sapiente nostrum recusandae optio, sequi ullam, reiciendis quisquam nobis quia.</p>
  			<div>
				<p>Lorem ipsum dolor sit amet, consectetur adipisicing elit. Error quo expedita quidem dicta quas molestiae atque odit, voluptatibus asperiores laudantium accusamus iusto deserunt doloribus necessitatibus. Sit quibusdam necessitatibus, dolores explicabo.</p>
				<p>Lorem ipsum dolor sit amet, consectetur adipisicing elit. Nostrum vero unde quis dicta porro dolorem itaque nam esse quaerat, recusandae eveniet, nisi animi repudiandae ipsa voluptate velit impedit! Quos, impedit.</p>
				<p>Lorem ipsum dolor sit amet, consectetur adipisicing elit. Aspernatur corporis voluptate magni quibusdam obcaecati odit nostrum repellat architecto amet, dolores repudiandae necessitatibus aliquam sit iure deserunt suscipit distinctio dolor magnam?</p>
			 </div>
 		 </div>
	
 </div>
</body>
</html>